package com.example.rodrigo.bdmutantes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MutanteOperations {
    private SimpleBDWrapper dbHelper;
    private String[] MUTANTE_TABLE_COLUMNS = { SimpleBDWrapper.MUTANTE_NAME, SimpleBDWrapper.MUTANTE_SKILL};
    private SQLiteDatabase database;

    public MutanteOperations(Context context){
        dbHelper = new SimpleBDWrapper(context);
    }

    public void open() throws SQLException{
        database = dbHelper.getWritableDatabase();
    }

    public void close(){
        dbHelper.close();
    }

    public String addMutante(String name, String skill){
        open();

        ContentValues values = new ContentValues();


        if(name.isEmpty() || skill.isEmpty()){
            return "Erro ao inserir registro: Preencher todos os valores";
        }

        values.put(SimpleBDWrapper.MUTANTE_NAME, name);
        values.put(SimpleBDWrapper.MUTANTE_SKILL, skill);



        long resultado = database.insert(SimpleBDWrapper.MUTANTES, null, values);

        database.close();

        if (resultado ==-1)
            return "Erro ao inserir registro";
        else
            return "Registro Inserido com sucesso";
    }

    private Mutante parseMutante(Cursor cursor)
    {
        Mutante mutante = new Mutante();
        mutante.setName((cursor.getString(0)));
        mutante.setHabilidades(cursor.getString(1));
        return mutante;
    }

    public List<Mutante> getAllMutantes()
    {
        open();
        List mutantes = new ArrayList();
        Cursor cursor = database.query(SimpleBDWrapper.MUTANTES, MUTANTE_TABLE_COLUMNS, null, null, null, null, null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast())
        {
            Mutante mutante = parseMutante(cursor);
            mutantes.add(mutante);
            cursor.moveToNext();
        }
        cursor.close();
        return mutantes;
    }

    public List<Mutante> getMutantesByFilter(String nameFilter, String skillFilter)
    {
        open();
        List mutantes = new ArrayList();
        String where = "";
        String[] whereArgs = new String[]{};

        if (!nameFilter.equals("")  && skillFilter.equals("")) {
            where = "_name=?";
            whereArgs = new String[] {
                    nameFilter
            };
        }
        else if (nameFilter.equals("") && !skillFilter.equals("")) {
            where = "_skill=?";
            whereArgs = new String[] {
                    skillFilter
            };
        }
        else
            {
            where = "_name=? and _skill=?";
        whereArgs = new String[] {
                '%'+nameFilter+'%', '%'+skillFilter+'%'
        };
        }
            Cursor cursor = database.query(SimpleBDWrapper.MUTANTES, MUTANTE_TABLE_COLUMNS, where, whereArgs, null, null, null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast())
        {
            Mutante mutante = parseMutante(cursor);
            mutantes.add(mutante);
            cursor.moveToNext();
        }
        cursor.close();
        return mutantes;
    }

    public String deleteMutante(String name){
        open();
        String where = "_name=?";
        String[] whereArgs = new String[]{ name };

        long resultado = database.delete(SimpleBDWrapper.MUTANTES, where, whereArgs);

        database.close();

        if (resultado ==-1)
            return "Erro ao deletar registro";
        else
            return "Registro deletado com sucesso";
    }

    public String updateMutante(String nameFilter, String skillFilter){
        open();

        ContentValues cv = new ContentValues();
        cv.put("_name", nameFilter);
        cv.put("_skill", skillFilter);

        String whereClause = "_name=?";
        String[] whereArgs = new String[]{ nameFilter};

        long resultado = database.update(SimpleBDWrapper.MUTANTES, cv, whereClause, whereArgs);

        database.close();

        if (resultado ==-1)
            return "Erro ao atualizar registro";
        else
            return "Registro atualizado com sucesso";
    }
}
